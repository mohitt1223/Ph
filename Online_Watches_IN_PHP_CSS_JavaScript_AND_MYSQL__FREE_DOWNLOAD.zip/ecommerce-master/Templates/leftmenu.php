<div class="divLeftMenu">
    <nav>
        <ul id="ulLeftMenu">
            <script language="javascript">
                showLeftMenu();
            </script>
        </ul>
    </nav>
</div>