<div class="divTopMenu">
    <nav>
        <ul id="ulTopMenu"> 
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="contact.php">Liên hệ</a></li>
            <li><a href="search.php">Tìm kiếm</a></li>
            <li><a href="checkorder.php">Kiểm tra đơn hàng</a></li>
        </ul>
    </nav>
</div>